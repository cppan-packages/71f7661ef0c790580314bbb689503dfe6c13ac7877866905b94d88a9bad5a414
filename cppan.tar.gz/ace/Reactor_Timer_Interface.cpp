#include "ace/Reactor_Timer_Interface.h"

ACE_BEGIN_VERSIONED_NAMESPACE_DECL

ACE_Reactor_Timer_Interface::~ACE_Reactor_Timer_Interface()
{
}

ACE_END_VERSIONED_NAMESPACE_DECL
