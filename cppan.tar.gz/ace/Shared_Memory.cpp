#include "ace/Shared_Memory.h"



ACE_BEGIN_VERSIONED_NAMESPACE_DECL

ACE_Shared_Memory::~ACE_Shared_Memory (void)
{
}

ACE_END_VERSIONED_NAMESPACE_DECL
