#include "ace/OS_TLI.h"



#if !defined (ACE_HAS_INLINED_OSCALLS)
# include "ace/OS_TLI.inl"
#endif /* !ACE_HAS_INLINED_OSCALLS */
